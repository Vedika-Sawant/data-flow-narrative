
import React, { useState, useEffect } from 'react';
import { NetworkModelData, LayerData } from '../utils/modelData';

interface AnimatedDataProps {
  model: NetworkModelData;
  direction: 'up' | 'down';
  selectedLayer: LayerData | null;
}

const AnimatedData: React.FC<AnimatedDataProps> = ({ model, direction, selectedLayer }) => {
  const [animationStage, setAnimationStage] = useState(0);
  const totalLayers = model.layers.length;
  
  useEffect(() => {
    // Reset animation when component mounts
    setAnimationStage(0);
    
    // Create a controlled animation sequence with predictable timing
    const totalAnimationTime = 4000; // 4 seconds total
    const stageTime = totalAnimationTime / (totalLayers + 1); // +1 for final state
    
    // Create intervals for each stage
    const intervals: NodeJS.Timeout[] = [];
    
    for (let i = 1; i <= totalLayers + 1; i++) {
      const timer = setTimeout(() => {
        setAnimationStage(i);
      }, stageTime * i);
      intervals.push(timer);
    }
    
    // Clean up all intervals on unmount
    return () => {
      intervals.forEach(clearTimeout);
    };
  }, [totalLayers]);
  
  // Determine which layers to render based on the current animation stage
  const layersToRender = direction === 'down' 
    ? model.layers.slice(0, animationStage)
    : model.layers.slice(model.layers.length - animationStage).reverse();
  
  const getTransmissionType = () => {
    return direction === 'down' ? 'Sender (Encapsulation)' : 'Receiver (Decapsulation)';
  };
  
  const getPacketSizeClass = (index: number, total: number) => {
    // In encapsulation (down), packets grow in size as headers are added
    // In decapsulation (up), packets shrink as headers are removed
    if (direction === 'down') {
      return `scale-${100 + (index * 5)}`;
    } else {
      return `scale-${100 + ((total - index) * 5)}`;
    }
  };
  
  if (layersToRender.length === 0) return null;
  
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
      <div className="relative max-w-md w-full bg-background/90 rounded-lg p-4 border border-border shadow-xl">
        <div className="text-center mb-4">
          <h3 className="text-lg font-semibold text-foreground">
            Data Transmission: {getTransmissionType()}
          </h3>
          <p className="text-sm text-foreground/70">
            {direction === 'down' 
              ? 'Data flows downward with added headers at each layer' 
              : 'Data flows upward with headers removed at each layer'}
          </p>
        </div>
        
        <div className="space-y-4">
          {layersToRender.map((layer, index) => {
            const isLast = index === layersToRender.length - 1;
            const nextLayer = !isLast ? layersToRender[index + 1] : null;
            
            return (
              <div 
                key={layer.id}
                className={`
                  p-4 rounded-lg border
                  bg-${layer.color}/10 border-${layer.color}/30
                  transition-all duration-500 ease-in-out
                  ${isLast ? 'animate-pulse-soft' : ''}
                `}
                style={{
                  animationDelay: `${index * 0.5}s`,
                  transform: `translateY(${direction === 'down' ? '0' : '0'}px)`
                }}
              >
                <div className="flex justify-between items-center mb-2">
                  <div className={`text-sm font-medium text-${layer.color}`}>
                    {layer.name}
                  </div>
                  <div className={`text-xs px-2 py-0.5 rounded-full bg-${layer.color}/30 text-${layer.color}/90`}>
                    {layer.dataUnit}
                  </div>
                </div>
                
                <div className={`p-3 rounded bg-${layer.color}/20 font-mono text-xs text-center relative mb-2`}>
                  {direction === 'down' && (
                    <div className={`absolute -top-2 left-4 px-2 text-xs bg-${layer.color}/40 rounded-full text-white`}>
                      {isLast ? 'Data' : '+Header'}
                    </div>
                  )}
                  {direction === 'up' && (
                    <div className={`absolute -top-2 left-4 px-2 text-xs bg-${layer.color}/40 rounded-full text-white`}>
                      {isLast ? 'Original Data' : '-Header'}
                    </div>
                  )}
                  
                  <div className="relative overflow-hidden">
                    {layer.dataUnit === "Segment" && <span>[TCP Header] [Data] [Checksum]</span>}
                    {layer.dataUnit === "Datagram" && <span>[UDP Header] [Data]</span>}
                    {layer.dataUnit === "Packet" && <span>[IP Header] [Data]</span>}
                    {layer.dataUnit === "Frame" && <span>[Frame Header] [Data] [Frame Trailer]</span>}
                    {layer.dataUnit === "Bit" && <span>101010101</span>}
                    {layer.dataUnit === "Data" && <span>{"{Application Data}"}</span>}
                  </div>
                </div>
                
                {!isLast && (
                  <div className="flex justify-center my-2">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className={`text-${nextLayer?.color} animate-bounce`}
                    >
                      <path d="M12 5v14"/>
                      <path d="M19 12l-7 7-7-7"/>
                    </svg>
                  </div>
                )}
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 text-center text-sm text-foreground/70">
          {animationStage > totalLayers 
            ? `${direction === 'down' ? 'Encapsulation' : 'Decapsulation'} complete` 
            : `${direction === 'down' ? 'Encapsulating' : 'Decapsulating'} data: Stage ${animationStage}/${totalLayers}`
          }
        </div>
      </div>
    </div>
  );
};

export default AnimatedData;
