
import React, { useState } from 'react';
import { NetworkModelData, LayerData } from '../utils/modelData';
import ModelLayer from './ModelLayer';
import LayerDetails from './LayerDetails';
import AnimatedData from './AnimatedData';

interface NetworkModelProps {
  model: NetworkModelData;
  direction?: 'up' | 'down';
}

const NetworkModel: React.FC<NetworkModelProps> = ({ model, direction = 'down' }) => {
  const [selectedLayer, setSelectedLayer] = useState<LayerData | null>(null);
  const [animateFlow, setAnimateFlow] = useState(false);
  const [isAnimating, setIsAnimating] = useState(false);
  
  const layers = direction === 'down' ? [...model.layers] : [...model.layers].reverse();
  
  const handleLayerSelect = (layer: LayerData) => {
    setSelectedLayer(layer === selectedLayer ? null : layer);
  };

  const startAnimation = () => {
    if (isAnimating) return; // Prevent multiple animations running simultaneously
    
    setIsAnimating(true);
    setAnimateFlow(true);
    
    // Reset animation state after completion
    setTimeout(() => {
      setAnimateFlow(false);
      setIsAnimating(false);
    }, 4000); // Match this to the total animation duration in AnimatedData
  };

  return (
    <div className="relative">
      <div className="mb-8 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-2">{model.name}</h2>
        <p className="text-foreground/70 max-w-3xl mx-auto">{model.description}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="model-container md:col-span-1">
          {layers.map((layer, index) => (
            <ModelLayer 
              key={layer.id}
              layer={layer}
              index={index}
              totalLayers={model.layers.length}
              direction={direction}
              onSelect={handleLayerSelect}
              isActive={selectedLayer?.id === layer.id}
            />
          ))}
          
          <button 
            className={`mt-4 interactive-button ${isAnimating ? 'opacity-50 cursor-not-allowed' : 'bg-primary hover:bg-primary/80'} text-primary-foreground`}
            onClick={startAnimation}
            disabled={isAnimating}
          >
            {isAnimating ? 'Simulating...' : 'Simulate Data Flow'}
          </button>
        </div>
        
        <div className="md:col-span-2 relative min-h-[400px]">
          {selectedLayer ? (
            <div className="animate-scale-in">
              <LayerDetails layer={selectedLayer} />
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-center">
              <div className="bg-secondary/50 p-8 rounded-lg max-w-md glass-card">
                <h3 className="text-xl font-semibold mb-4">Interactive Model</h3>
                <p className="text-foreground/70 mb-6">Click on any layer to see detailed information about its function, protocols, and examples.</p>
                <p className="text-primary/80 text-sm">Select "Simulate Data Flow" to visualize data encapsulation/decapsulation through the layers.</p>
              </div>
            </div>
          )}
          
          {animateFlow && (
            <AnimatedData 
              model={model} 
              direction={direction} 
              selectedLayer={selectedLayer}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default NetworkModel;
