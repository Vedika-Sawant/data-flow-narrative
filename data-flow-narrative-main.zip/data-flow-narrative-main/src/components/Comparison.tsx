
import React, { useState } from 'react';
import { tcpipModel, osiModel, modelComparison } from '../utils/modelData';
import NetworkModel from './NetworkModel';

const Comparison: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'visual' | 'table'>('visual');

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-3">Model Comparison</h2>
        <p className="text-foreground/70 max-w-3xl mx-auto">
          Explore the differences between the TCP/IP and OSI models and understand how they relate to each other.
        </p>
      </div>

      <div className="bg-secondary/30 rounded-lg p-4 mb-8">
        <div className="flex justify-center space-x-4 mb-6">
          <button
            className={`px-6 py-2 rounded-md transition-all ${
              activeTab === 'visual'
                ? 'bg-primary text-primary-foreground'
                : 'bg-secondary/50 text-foreground/70 hover:bg-secondary'
            }`}
            onClick={() => setActiveTab('visual')}
          >
            Visual Comparison
          </button>
          <button
            className={`px-6 py-2 rounded-md transition-all ${
              activeTab === 'table'
                ? 'bg-primary text-primary-foreground'
                : 'bg-secondary/50 text-foreground/70 hover:bg-secondary'
            }`}
            onClick={() => setActiveTab('table')}
          >
            Detailed Comparison
          </button>
        </div>

        {activeTab === 'visual' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <NetworkModel model={tcpipModel} direction="down" />
            </div>
            <div>
              <NetworkModel model={osiModel} direction="down" />
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse glass-card">
              <thead>
                <tr className="bg-secondary/50">
                  <th className="p-4 text-left border-b border-white/10">Aspect</th>
                  <th className="p-4 text-left border-b border-white/10">TCP/IP Model</th>
                  <th className="p-4 text-left border-b border-white/10">OSI Model</th>
                </tr>
              </thead>
              <tbody>
                {modelComparison.map((item, index) => (
                  <tr 
                    key={index} 
                    className={index % 2 === 0 ? 'bg-secondary/20' : 'bg-transparent'}
                  >
                    <td className="p-4 border-b border-white/10 font-medium">{item.aspect}</td>
                    <td className="p-4 border-b border-white/10">{item.tcpip}</td>
                    <td className="p-4 border-b border-white/10">{item.osi}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            <div className="mt-8 p-6 rounded-lg glass-card">
              <h3 className="text-xl font-semibold mb-4">Model Relationship</h3>
              <p className="mb-4">The OSI and TCP/IP models represent similar network functions but with different approaches. The TCP/IP model combines several OSI layers for practical implementation:</p>
              
              <div className="flex flex-col md:flex-row gap-6 mb-4">
                <div className="flex-1 bg-secondary/30 p-4 rounded-lg">
                  <h4 className="text-lg font-medium mb-3 text-primary">OSI to TCP/IP Mapping</h4>
                  <ul className="space-y-2">
                    <li className="flex justify-between items-center p-2 border-b border-white/10">
                      <span>Application, Presentation, Session</span>
                      <span className="text-layer-1">→</span>
                      <span className="font-medium text-layer-1">Application Layer</span>
                    </li>
                    <li className="flex justify-between items-center p-2 border-b border-white/10">
                      <span>Transport</span>
                      <span className="text-layer-2">→</span>
                      <span className="font-medium text-layer-2">Transport Layer</span>
                    </li>
                    <li className="flex justify-between items-center p-2 border-b border-white/10">
                      <span>Network</span>
                      <span className="text-layer-3">→</span>
                      <span className="font-medium text-layer-3">Internet Layer</span>
                    </li>
                    <li className="flex justify-between items-center p-2">
                      <span>Data Link, Physical</span>
                      <span className="text-layer-4">→</span>
                      <span className="font-medium text-layer-4">Link Layer</span>
                    </li>
                  </ul>
                </div>
                
                <div className="flex-1 bg-secondary/30 p-4 rounded-lg">
                  <h4 className="text-lg font-medium mb-3 text-primary">Key Differences</h4>
                  <ul className="space-y-3 list-disc list-inside">
                    <li>TCP/IP is implementation-focused while OSI is conceptual</li>
                    <li>TCP/IP was developed before OSI but mapped to it later</li>
                    <li>TCP/IP combines three OSI layers at the application level</li>
                    <li>TCP/IP combines two OSI layers at the link level</li>
                    <li>TCP/IP is widely implemented while OSI serves as reference</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Comparison;
