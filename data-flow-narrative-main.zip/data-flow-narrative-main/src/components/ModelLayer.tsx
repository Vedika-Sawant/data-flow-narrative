
import React, { useState } from 'react';
import { LayerData } from '../utils/modelData';

interface ModelLayerProps {
  layer: LayerData;
  index: number;
  totalLayers: number;
  direction: 'up' | 'down';
  onSelect: (layer: LayerData) => void;
  isActive: boolean;
}

const ModelLayer: React.FC<ModelLayerProps> = ({ 
  layer, 
  index, 
  totalLayers, 
  direction, 
  onSelect,
  isActive 
}) => {
  const [hover, setHover] = useState(false);
  
  // Calculate opacity based on position (farther layers are more transparent)
  const getOpacity = () => {
    if (isActive) return 1;
    const normalizedPosition = direction === 'down' 
      ? index / totalLayers 
      : (totalLayers - index) / totalLayers;
    return 0.5 + (normalizedPosition * 0.5);
  };
  
  const handleClick = () => {
    onSelect(layer);
  };

  return (
    <div 
      className={`
        animate-stagger layer-card bg-${layer.color}/20 border border-${layer.color}/40
        ${isActive ? `active-layer ring-${layer.color}` : ''}
      `}
      onClick={handleClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ opacity: getOpacity() }}
    >
      <div className="flex justify-between items-center">
        <h3 className={`font-semibold text-${layer.color}`}>{layer.name}</h3>
        <span className={`text-xs px-2 py-1 rounded-full bg-${layer.color}/30 text-${layer.color}`}>
          {layer.dataUnit}
        </span>
      </div>
      
      <div className="layer-content">
        <p className="text-foreground/80 mb-2">{layer.description}</p>
        
        <div className="mb-2">
          <h4 className="text-xs font-semibold uppercase text-foreground/60">Key Protocols</h4>
          <div className="flex flex-wrap gap-1 mt-1">
            {layer.protocols.slice(0, 5).map((protocol) => (
              <span 
                key={protocol} 
                className={`text-xs px-2 py-0.5 rounded-full bg-${layer.color}/20 text-${layer.color}/90`}
              >
                {protocol}
              </span>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="text-xs font-semibold uppercase text-foreground/60">Functions</h4>
          <ul className="list-disc list-inside text-xs text-foreground/80 mt-1">
            {layer.functionality.slice(0, 3).map((func, i) => (
              <li key={i}>{func}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ModelLayer;
