
import React from 'react';
import { LayerData } from '../utils/modelData';

interface LayerDetailsProps {
  layer: LayerData;
}

const LayerDetails: React.FC<LayerDetailsProps> = ({ layer }) => {
  return (
    <div className={`p-6 rounded-lg glass-card bg-${layer.color}/5 border border-${layer.color}/20`}>
      <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <h3 className={`text-2xl font-bold text-${layer.color}`}>{layer.name}</h3>
            <span className={`text-sm px-2 py-1 rounded-full bg-${layer.color}/20 text-${layer.color}/90`}>
              {layer.dataUnit}
            </span>
          </div>
          <p className="text-foreground/80">{layer.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className={`text-sm font-semibold uppercase mb-3 text-${layer.color}`}>Key Protocols</h4>
          <div className="flex flex-wrap gap-2">
            {layer.protocols.map((protocol) => (
              <span
                key={protocol}
                className={`text-sm px-3 py-1 rounded-full bg-${layer.color}/20 text-${layer.color}/90`}
              >
                {protocol}
              </span>
            ))}
          </div>
        </div>

        <div>
          <h4 className={`text-sm font-semibold uppercase mb-3 text-${layer.color}`}>Core Functionality</h4>
          <ul className="space-y-2">
            {layer.functionality.map((func, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className={`mt-1 h-2 w-2 rounded-full bg-${layer.color}`}></span>
                <span className="text-foreground/80">{func}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-6">
        <h4 className={`text-sm font-semibold uppercase mb-3 text-${layer.color}`}>Real-World Examples</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {layer.examples.map((example, index) => (
            <div 
              key={index} 
              className={`p-3 rounded-md bg-${layer.color}/10 border border-${layer.color}/20`}
            >
              <p className="text-foreground/90">{example}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <h4 className={`text-sm font-semibold uppercase mb-3 text-${layer.color}`}>Data Unit Details</h4>
        <div className={`p-4 rounded-md bg-${layer.color}/10 border border-${layer.color}/20`}>
          <div className="flex flex-col sm:flex-row gap-4 items-center">
            <div className={`relative p-4 rounded-md bg-${layer.color}/20 border border-${layer.color}/40 w-full sm:w-auto`}>
              <div className="flex justify-between items-center gap-8">
                <div className={`text-${layer.color} font-mono`}>
                  {layer.dataUnit === "Segment" && "[TCP Header] [Data] [Checksum]"}
                  {layer.dataUnit === "Datagram" && "[UDP Header] [Data]"}
                  {layer.dataUnit === "Packet" && "[IP Header] [Data]"}
                  {layer.dataUnit === "Frame" && "[Frame Header] [Data] [Frame Trailer]"}
                  {layer.dataUnit === "Bit" && "101010101"}
                  {layer.dataUnit === "Data" && "{Application Data}"}
                </div>
              </div>
            </div>
            <div className="text-sm text-foreground/70">
              {layer.dataUnit === "Segment" && "TCP segments include headers with source/destination ports, sequence numbers, and checksums for reliability."}
              {layer.dataUnit === "Datagram" && "UDP datagrams contain minimal headers with just port information, making them faster but less reliable."}
              {layer.dataUnit === "Packet" && "IP packets contain logical addressing information needed to route data across networks."}
              {layer.dataUnit === "Frame" && "Frames add physical addressing and error detection to ensure proper delivery on the local network."}
              {layer.dataUnit === "Bit" && "The raw binary data transmitted over the physical medium as electrical, light, or radio signals."}
              {layer.dataUnit === "Data" && "The actual information from the application before any network-specific headers are added."}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LayerDetails;
