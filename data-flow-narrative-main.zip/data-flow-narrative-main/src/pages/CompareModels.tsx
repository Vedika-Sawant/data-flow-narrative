
import React from 'react';
import Header from '../components/Header';
import NetworkModel from '../components/NetworkModel';
import { osiModel, tcpipModel } from '../utils/modelData';
import { Button } from '../components/ui/button';

const CompareModels = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95">
      <Header />
      
      <div className="pt-24 pb-16 px-4">
        <div className="container mx-auto">
          <div className="mb-10 text-center max-w-3xl mx-auto">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">TCP/IP vs OSI Model Comparison</h1>
            <p className="text-foreground/80 mb-6">
              Compare how data flows through both models. The OSI model has 7 layers for a more detailed 
              approach, while the TCP/IP model combines these into 4 functional layers.
            </p>
            <div className="grid grid-cols-2 gap-4 md:gap-6 max-w-xl mx-auto p-4 bg-accent/20 rounded-lg">
              <div className="text-center">
                <h3 className="font-medium text-primary">TCP/IP Model</h3>
                <p className="text-sm text-foreground/70">4 Layers - Industry Standard</p>
              </div>
              <div className="text-center">
                <h3 className="font-medium text-primary">OSI Model</h3>
                <p className="text-sm text-foreground/70">7 Layers - Conceptual Model</p>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-4">
            <div className="bg-card/20 rounded-xl p-4 shadow-lg border border-border/50">
              <NetworkModel model={tcpipModel} direction="down" />
            </div>
            
            <div className="bg-card/20 rounded-xl p-4 shadow-lg border border-border/50">
              <NetworkModel model={osiModel} direction="down" />
            </div>
          </div>
          
          <div className="mt-12 p-6 bg-secondary/30 rounded-xl border border-border/50">
            <h2 className="text-2xl font-semibold mb-4">Key Differences Explained</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-card/20 p-4 rounded-lg border border-border/50">
                <h3 className="text-lg font-medium mb-2 text-primary">Layer Count</h3>
                <p className="text-sm text-foreground/80">
                  TCP/IP uses 4 layers, combining several OSI layers together for a more practical implementation.
                  OSI's 7 layers provide a more detailed theoretical framework.
                </p>
              </div>
              
              <div className="bg-card/20 p-4 rounded-lg border border-border/50">
                <h3 className="text-lg font-medium mb-2 text-primary">Development Approach</h3>
                <p className="text-sm text-foreground/80">
                  TCP/IP was developed based on real-world protocols.
                  OSI was developed as a standardized theoretical model for network communications.
                </p>
              </div>
              
              <div className="bg-card/20 p-4 rounded-lg border border-border/50">
                <h3 className="text-lg font-medium mb-2 text-primary">Practical Usage</h3>
                <p className="text-sm text-foreground/80">
                  TCP/IP is widely implemented in real networks and the internet.
                  OSI is primarily used as a reference for understanding network concepts and troubleshooting.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompareModels;
