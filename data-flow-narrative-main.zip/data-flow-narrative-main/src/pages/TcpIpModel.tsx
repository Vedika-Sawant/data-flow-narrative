
import React from 'react';
import Header from '../components/Header';
import NetworkModel from '../components/NetworkModel';
import { tcpipModel } from '../utils/modelData';

const TcpIpModel = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95">
      <Header />
      
      <div className="pt-24 pb-16 px-4">
        <div className="container mx-auto">
          <NetworkModel model={tcpipModel} direction="down" />
        </div>
      </div>
    </div>
  );
};

export default TcpIpModel;
