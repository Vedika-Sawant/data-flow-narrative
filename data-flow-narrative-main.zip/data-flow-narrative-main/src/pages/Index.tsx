
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import NetworkModel from '../components/NetworkModel';
import Comparison from '../components/Comparison';
import { tcpipModel, osiModel, dataFlowConcepts } from '../utils/modelData';

const Index = () => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Create animation for the hero section
    const animateHero = () => {
      const elements = document.querySelectorAll('.hero-animate');
      elements.forEach((el, index) => {
        el.classList.add('animate-fade-in');
        (el as HTMLElement).style.animationDelay = `${index * 0.2}s`;
      });
    };

    animateHero();
  }, []);

  const scrollToContent = () => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/95">
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 text-center">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.1)_0,rgba(16,185,129,0.05)_25%,transparent_50%)]"></div>
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/10 rounded-full filter blur-3xl opacity-30"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-layer-4/10 rounded-full filter blur-3xl opacity-30"></div>
        </div>
        
        <div className="relative z-10 max-w-4xl">
          <div className="mb-4 inline-block hero-animate">
            <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/20 text-primary">
              Interactive Learning
            </span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 hero-animate">
            Understanding Network <br />
            <span className="text-primary">Communication Models</span>
          </h1>
          <p className="text-xl text-foreground/70 mb-8 max-w-2xl mx-auto hero-animate">
            Explore how data travels through networks with detailed visualizations of the TCP/IP and OSI models.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16 hero-animate">
            <button 
              onClick={scrollToContent}
              className="interactive-button bg-primary hover:bg-primary/80 text-primary-foreground px-8 py-3 rounded-lg"
            >
              Start Exploring
            </button>
            <Link 
              to="/compare" 
              className="interactive-button bg-secondary hover:bg-secondary/80 text-secondary-foreground px-8 py-3 rounded-lg"
            >
              Compare Models
            </Link>
          </div>
          
          <div className="flex justify-center hero-animate">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="24" 
              height="24" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="animate-bounce text-foreground/50"
              onClick={scrollToContent}
            >
              <path d="M12 5v14"/>
              <path d="M19 12l-7 7-7-7"/>
            </svg>
          </div>
        </div>
      </section>
      
      {/* Concept Overview Section */}
      <section ref={scrollRef} className="py-20 px-4">
        <div className="container mx-auto">
          <div className="mb-16 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Network Communication Fundamentals</h2>
            <p className="text-foreground/70 max-w-3xl mx-auto">
              Before diving into the models, let's understand the key concepts of network data flow.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {dataFlowConcepts.map((concept, index) => (
              <div 
                key={index} 
                className="glass-card p-6 rounded-lg hover:scale-105 transition-transform"
              >
                <h3 className="text-xl font-semibold mb-3 text-primary">{concept.name}</h3>
                <p className="text-foreground/70 mb-4">{concept.description}</p>
                <div className="bg-secondary/30 p-3 rounded-md text-sm text-center font-mono">
                  {concept.visualCue}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* TCP/IP Model Section */}
      <section className="py-20 px-4 bg-secondary/10">
        <div className="container mx-auto">
          <NetworkModel model={tcpipModel} direction="down" />
        </div>
      </section>
      
      {/* OSI Model Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <NetworkModel model={osiModel} direction="down" />
        </div>
      </section>
      
      {/* Comparison Section */}
      <section className="py-20 px-4 bg-secondary/10">
        <Comparison />
      </section>
      
      {/* Footer */}
      <footer className="py-12 bg-background/80 border-t border-white/10">
        <div className="container mx-auto px-4 text-center">
          <p className="text-foreground/50 mb-2">
            An interactive educational tool for understanding network communication models
          </p>
          <div className="flex justify-center space-x-8 mb-6">
            <Link to="/" className="text-foreground/70 hover:text-primary transition-colors">Home</Link>
            <Link to="/tcp-ip" className="text-foreground/70 hover:text-primary transition-colors">TCP/IP Model</Link>
            <Link to="/osi" className="text-foreground/70 hover:text-primary transition-colors">OSI Model</Link>
            <Link to="/compare" className="text-foreground/70 hover:text-primary transition-colors">Compare</Link>
          </div>
          <div className="text-foreground/30 text-sm">
            © {new Date().getFullYear()} NetworkEDU
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
