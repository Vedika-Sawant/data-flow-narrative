
export interface LayerData {
  id: string;
  name: string;
  color: string;
  description: string;
  protocols: string[];
  dataUnit: string;
  functionality: string[];
  examples: string[];
}

export interface NetworkModelData {
  id: string;
  name: string;
  description: string;
  layers: LayerData[];
}

export const tcpipModel: NetworkModelData = {
  id: "tcpip",
  name: "TCP/IP Model",
  description: "The TCP/IP model is a concise framework with four layers that describes the communication and connection of systems on the internet.",
  layers: [
    {
      id: "application",
      name: "Application Layer",
      color: "layer-1",
      description: "Responsible for end-user services, application functionality, and data formatting.",
      protocols: ["HTTP", "HTTPS", "FTP", "SMTP", "DNS", "TLS/SSL", "DHCP"],
      dataUnit: "Data",
      functionality: [
        "User interfaces and services",
        "Data formatting",
        "Encryption (TLS/SSL)",
        "Authentication",
        "Content negotiation"
      ],
      examples: [
        "Web browsers using HTTP/HTTPS",
        "Email clients using SMTP/POP/IMAP",
        "DNS lookup resolving domain names"
      ]
    },
    {
      id: "transport",
      name: "Transport Layer",
      color: "layer-2",
      description: "Manages end-to-end communication, segmentation, flow control, and error recovery.",
      protocols: ["TCP", "UDP", "QUIC", "DCCP", "SCTP"],
      dataUnit: "Segment (TCP) / Datagram (UDP)",
      functionality: [
        "Connection-oriented (TCP) or connectionless (UDP) communication",
        "Flow control",
        "Error detection and correction",
        "Segmentation and reassembly",
        "Port addressing"
      ],
      examples: [
        "TCP ensuring reliable web page loading",
        "UDP for fast video streaming",
        "Port numbers identifying different services"
      ]
    },
    {
      id: "internet",
      name: "Internet Layer",
      color: "layer-3",
      description: "Handles packet routing across different networks and internetworks.",
      protocols: ["IP (IPv4, IPv6)", "ICMP", "ARP", "IGMP"],
      dataUnit: "Packet/Datagram",
      functionality: [
        "Logical addressing (IP addressing)",
        "Routing between networks",
        "Packet forwarding",
        "Fragmentation and reassembly",
        "Traffic control"
      ],
      examples: [
        "IP addressing for unique device identification",
        "Routers using routing tables to direct packets",
        "ICMP for error messages and diagnostics"
      ]
    },
    {
      id: "link",
      name: "Link Layer",
      color: "layer-4",
      description: "Manages physical addressing and network media access including hardware interfaces.",
      protocols: ["Ethernet", "Wi-Fi (IEEE 802.11)", "PPP", "MAC"],
      dataUnit: "Frame/Bits",
      functionality: [
        "Physical addressing (MAC addresses)",
        "Media access control",
        "Error detection at hardware level",
        "Hardware interface to network media",
        "Frame synchronization"
      ],
      examples: [
        "Ethernet frames on local networks",
        "MAC addresses for device identification",
        "Wi-Fi signals transmitting data wirelessly"
      ]
    }
  ]
};

export const osiModel: NetworkModelData = {
  id: "osi",
  name: "OSI Model",
  description: "The OSI (Open Systems Interconnection) model standardizes the functions of a communication system into seven abstraction layers.",
  layers: [
    {
      id: "application-osi",
      name: "Application Layer",
      color: "layer-1",
      description: "Closest to the end user, providing network services directly to applications.",
      protocols: ["HTTP", "HTTPS", "FTP", "SMTP", "SNMP", "Telnet"],
      dataUnit: "Data",
      functionality: [
        "End-user application access",
        "Resource sharing",
        "Remote file access",
        "Directory services",
        "Network virtual terminals"
      ],
      examples: [
        "Web browsers",
        "Email clients",
        "File transfer applications"
      ]
    },
    {
      id: "presentation-osi",
      name: "Presentation Layer",
      color: "layer-6",
      description: "Ensures data is in a usable format and handles data encryption/decryption.",
      protocols: ["TLS/SSL", "JPEG", "MPEG", "ASCII", "EBCDIC"],
      dataUnit: "Data",
      functionality: [
        "Data translation",
        "Encryption/Decryption",
        "Compression/Decompression",
        "Character set conversion",
        "MIME encoding"
      ],
      examples: [
        "Converting EBCDIC to ASCII",
        "JPEG image format conversion",
        "SSL encryption for secure web browsing"
      ]
    },
    {
      id: "session-osi",
      name: "Session Layer",
      color: "layer-5",
      description: "Establishes, manages, and terminates connections between applications.",
      protocols: ["NetBIOS", "RPC", "PPTP", "SAP"],
      dataUnit: "Data",
      functionality: [
        "Session establishment",
        "Session maintenance",
        "Session termination",
        "Authentication",
        "Dialog control (simplex, half-duplex, full-duplex)"
      ],
      examples: [
        "Login sessions",
        "Remote procedure calls",
        "SQL communication sessions"
      ]
    },
    {
      id: "transport-osi",
      name: "Transport Layer",
      color: "layer-2",
      description: "Provides reliable data transfer services between end systems.",
      protocols: ["TCP", "UDP", "SPX"],
      dataUnit: "Segment",
      functionality: [
        "End-to-end connection",
        "Reliability",
        "Flow control",
        "Multiplexing/Demultiplexing",
        "Error recovery"
      ],
      examples: [
        "TCP ensuring all packets arrive in order",
        "UDP for time-sensitive applications like video streaming",
        "Port addressing"
      ]
    },
    {
      id: "network-osi",
      name: "Network Layer",
      color: "layer-3",
      description: "Routes data packets between different networks and handles logical addressing.",
      protocols: ["IP", "ICMP", "OSPF", "RIP", "BGP"],
      dataUnit: "Packet",
      functionality: [
        "Logical addressing",
        "Path determination (routing)",
        "Traffic control",
        "Packet switching",
        "Subnet traffic control"
      ],
      examples: [
        "IP addresses",
        "Routers",
        "Subnet masks",
        "Routing tables"
      ]
    },
    {
      id: "datalink-osi",
      name: "Data Link Layer",
      color: "layer-4",
      description: "Provides node-to-node data transfer and error detection/correction.",
      protocols: ["Ethernet", "PPP", "HDLC", "Frame Relay", "ATM"],
      dataUnit: "Frame",
      functionality: [
        "Physical addressing (MAC)",
        "Framing",
        "Error detection and correction",
        "Media access control",
        "Flow control"
      ],
      examples: [
        "Ethernet frames",
        "MAC addresses",
        "CSMA/CD in traditional Ethernet",
        "Switches and bridges"
      ]
    },
    {
      id: "physical-osi",
      name: "Physical Layer",
      color: "layer-7",
      description: "Transmits raw bitstream over physical medium and deals with hardware specifications.",
      protocols: ["USB", "Bluetooth", "IEEE 802.11", "DSL", "ISDN"],
      dataUnit: "Bit",
      functionality: [
        "Bit transmission",
        "Physical connections",
        "Transmission mode",
        "Topology",
        "Signal encoding"
      ],
      examples: [
        "Cables and connectors",
        "Hubs and repeaters",
        "Network interface cards",
        "Radio signals in wireless networks"
      ]
    }
  ]
};

export const modelComparison = [
  {
    aspect: "Number of Layers",
    tcpip: "4 layers",
    osi: "7 layers",
    explanation: "TCP/IP combines several OSI layers for a more practical, implementation-focused approach."
  },
  {
    aspect: "Development Approach",
    tcpip: "Practical, developed from real-world implementation",
    osi: "Theoretical, developed as a reference model",
    explanation: "TCP/IP evolved from practical networking needs, while OSI was designed as a conceptual framework."
  },
  {
    aspect: "Protocol Specificity",
    tcpip: "Defines specific protocols for implementation",
    osi: "Protocol-agnostic, focuses on functions",
    explanation: "TCP/IP includes specific protocols like TCP, UDP, IP, while OSI defines what functions each layer should perform."
  },
  {
    aspect: "Adoption",
    tcpip: "Widely implemented in real networks",
    osi: "Primarily used as a reference model",
    explanation: "Most networks today run on TCP/IP, but use OSI model concepts for understanding networking."
  },
  {
    aspect: "Layer Interdependence",
    tcpip: "Some interdependence between layers",
    osi: "Strict independence between layers",
    explanation: "TCP/IP layers can have some overlap in functionality, while OSI enforces separation of concerns."
  }
];

export const dataFlowConcepts = [
  {
    name: "Encapsulation",
    description: "The process of adding header information to data as it moves down the network layers. Each layer adds its own header to the data from the layer above.",
    visualCue: "Adding layers around the original data"
  },
  {
    name: "Decapsulation",
    description: "The process of removing header information from data as it moves up the network layers. Each layer strips off its corresponding header.",
    visualCue: "Removing layers to reveal original data"
  },
  {
    name: "Headers & Trailers",
    description: "Control information added to data at each layer. Headers are added at the beginning, while trailers (like checksums) may be added at the end.",
    visualCue: "Colored blocks before and after data"
  },
  {
    name: "Protocol Data Units (PDUs)",
    description: "The data unit changes name at different layers: data, segment/datagram, packet, frame, bits.",
    visualCue: "Different shaped containers for data"
  }
];
