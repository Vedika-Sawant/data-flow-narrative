import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# Initialize global variables
data_bits = [1, 0, 1, 1]  # Example data bits
frames = []  # To store the animation frames
encoded_data = []


def calculate_parity(encoded, r):
    """
    Calculate and update parity bits in the encoded data.
    """
    for i in range(r):
        parity_pos = 2**i
        parity_value = 0
        for j in range(1, len(encoded) + 1):
            if j & parity_pos and j != parity_pos:
                parity_value ^= encoded[j - 1]
        encoded[parity_pos - 1] = parity_value
    return encoded


def hamming_encode(data_bits):
    """
    Encodes the data using Hamming Code (with parity bits).
    """
    global frames
    m = len(data_bits)
    r = 0

    # Calculate number of parity bits
    while (2**r) < (m + r + 1):
        r += 1

    # Initialize encoded data
    encoded = ['P' if (i & (i - 1)) == 0 else 'D' for i in range(1, m + r + 1)]

    # Insert data bits
    data_index = 0
    for i in range(len(encoded)):
        if encoded[i] == 'D':
            encoded[i] = data_bits[data_index]
            data_index += 1

    frames.append(("Adding Data Bits", encoded[:]))
    encoded = calculate_parity(encoded, r)
    frames.append(("Adding Parity Bits", encoded[:]))

    return encoded


def introduce_error(encoded, pos):
    """
    Introduce an error at a given position.
    """
    encoded[pos] ^= 1
    frames.append(("Introducing Error", encoded[:]))
    return encoded


def hamming_detect_and_correct(received):
    """
    Detects and corrects an error in the received data.
    """
    global frames
    n = len(received)
    error_pos = 0

    # Check parity bits
    for i in range(n):
        parity_pos = 2**i - 1
        if parity_pos >= n:
            break
        parity_check = 0
        for j in range(1, n + 1):
            if j & (parity_pos + 1) and j != (parity_pos + 1):
                parity_check ^= received[j - 1]
        if parity_check != received[parity_pos]:
            error_pos += (parity_pos + 1)

    if error_pos == 0:
        frames.append(("No Errors Detected", received[:]))
        return received

    frames.append((f"Error Detected at Position {error_pos}", received[:]))
    # Correct the error (ensure index is valid)
    if 0 < error_pos <= len(received):
        received[error_pos - 1] ^= 1
        frames.append(("Error Corrected", received[:]))
    else:
        frames.append(("Error Position Out of Bounds", received[:]))
    return received


# Animation Function
def animate(i):
    plt.clf()
    step, state = frames[i]
    plt.title("Hamming Code - Error Detection and Correction", fontsize=14)
    plt.text(0.5, 0.8, step, fontsize=12, ha='center', color="blue")
    plt.scatter(range(len(state)), [0] * len(state), s=100, c="lightblue", edgecolors="black")
    for j, bit in enumerate(state):
        plt.text(j, -0.1, str(bit), fontsize=12, ha='center')
    plt.xlim(-1, len(state))
    plt.ylim(-1, 1)
    plt.axis('off')


# Main Execution
encoded_data = hamming_encode(data_bits)
received_data = introduce_error(encoded_data[:], 2)  # Introduce error at position 2
corrected_data = hamming_detect_and_correct(received_data)

# Create Animation
fig = plt.figure()
ani = FuncAnimation(fig, animate, frames=len(frames), interval=2000, repeat=False)

plt.show()