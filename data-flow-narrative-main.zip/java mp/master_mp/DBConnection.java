import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    private static final String URL = "jdbc:sqlite:event.db"; // SQLite database file
    private static final String TABLE_CREATION_SQL =
            "CREATE TABLE IF NOT EXISTS events (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "name TEXT NOT NULL, " +
            "date TEXT NOT NULL, " +
            "time TEXT NOT NULL, " +
            "venue TEXT NOT NULL, " +
            "description TEXT" +
            ");";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC"); // Ensure SQLite JDBC Driver is loaded
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite JDBC Driver not found. Include the JAR file in classpath!");
            e.printStackTrace();
        }

            Connection conn = DriverManager.getConnection(URL);
            createTableIfNotExists(conn);
            return conn;
        }

        private static void createTableIfNotExists(Connection conn) {
            try (Statement stmt = conn.createStatement()) {
                stmt.execute(TABLE_CREATION_SQL);
            } catch (SQLException e) {
                System.out.println("Table creation error: " + e.getMessage());
        }
    }
}
