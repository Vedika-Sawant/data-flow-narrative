import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Date;

public class EventManagementSystem {
    private JFrame mainFrame;

    public EventManagementSystem() {
        mainFrame = new JFrame("Event Management System");
        mainFrame.setSize(600, 500);
        mainFrame.setLayout(new BorderLayout(10, 10));
        mainFrame.getContentPane().setBackground(new Color(240, 248, 255)); // Pastel light blue background

        // Header Panel with Pastel Color
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(176, 224, 230)); // Pastel turquoise
        headerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        JLabel headerLabel = new JLabel("Event Management System", SwingConstants.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 28));
        headerLabel.setForeground(new Color(70, 70, 70)); // Dark gray for text
        headerPanel.add(headerLabel);
        mainFrame.add(headerPanel, BorderLayout.NORTH);

        // Button Panel with Pastel Colors
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 1, 15, 15));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        buttonPanel.setBackground(new Color(240, 248, 255)); // Pastel light blue background

        JButton createButton = createStyledButton("Create Event", new Color(152, 251, 152)); // Pastel green
        JButton updateButton = createStyledButton("Update Event", new Color(173, 216, 230)); // Pastel blue
        JButton deleteButton = createStyledButton("Delete Event", new Color(255, 182, 193)); // Pastel pink
        JButton viewButton = createStyledButton("View Events", new Color(221, 160, 221)); // Pastel purple

        createButton.addActionListener(e -> createEventWindow("Create", ""));
        updateButton.addActionListener(e -> {
            String eventId = JOptionPane.showInputDialog("Enter Event ID to update:");
            if (eventId != null && !eventId.trim().isEmpty()) {
                createEventWindow("Update", eventId);
            }
        });
        deleteButton.addActionListener(e -> {
            String eventId = JOptionPane.showInputDialog("Enter Event ID to delete:");
            if (eventId != null && !eventId.trim().isEmpty()) {
                deleteEvent(eventId);
            }
        });
        viewButton.addActionListener(e -> viewEvents());

        buttonPanel.add(createButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);
        mainFrame.add(buttonPanel, BorderLayout.CENTER);

        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 18));
        button.setBackground(color);
        button.setForeground(new Color(70, 70, 70)); // Dark gray text
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    private void createEventWindow(String action, String eventId) {
        JFrame eventFrame = new JFrame(action + " Event");
        eventFrame.setSize(500, 400);
        eventFrame.setLayout(new GridLayout(7, 2, 10, 10));
        eventFrame.getContentPane().setBackground(new Color(240, 248, 255)); // Pastel light blue background

        JTextField idField = new JTextField(eventId);
        JTextField nameField = new JTextField();
        JDateChooser dateChooser = new JDateChooser();
        dateChooser.setDateFormatString("yyyy-MM-dd");
        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm:ss");
        timeSpinner.setEditor(timeEditor);
        JTextField venueField = new JTextField();
        JTextField descriptionField = new JTextField();
        JButton actionButton = createStyledButton(action, new Color(173, 216, 230)); // Pastel blue

        eventFrame.add(createStyledLabel("Event ID:"));
        eventFrame.add(idField);
        eventFrame.add(createStyledLabel("Event Name:"));
        eventFrame.add(nameField);
        eventFrame.add(createStyledLabel("Event Date:"));
        eventFrame.add(dateChooser);
        eventFrame.add(createStyledLabel("Event Time:"));
        eventFrame.add(timeSpinner);
        eventFrame.add(createStyledLabel("Venue:"));
        eventFrame.add(venueField);
        eventFrame.add(createStyledLabel("Description:"));
        eventFrame.add(descriptionField);
        eventFrame.add(new JLabel());
        eventFrame.add(actionButton);

        actionButton.addActionListener(e -> {
            if (dateChooser.getDate() == null) {
                JOptionPane.showMessageDialog(null, "Please select a valid date!");
                return;
            }
            if (action.equals("Create")) {
                insertEvent(nameField.getText(), dateChooser.getDate(), timeSpinner.getValue().toString(), venueField.getText(), descriptionField.getText());
            } else {
                updateEvent(idField.getText(), nameField.getText(), dateChooser.getDate(), timeSpinner.getValue().toString(), venueField.getText(), descriptionField.getText());
            }
        });

        eventFrame.setLocationRelativeTo(null);
        eventFrame.setVisible(true);
    }

    private JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(new Color(70, 70, 70)); // Dark gray text
        return label;
    }

    private void insertEvent(String name, Date date, String time, String venue, String description) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO events (name, date, time, venue, description) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setDate(2, new java.sql.Date(date.getTime()));
            pstmt.setString(3, time);
            pstmt.setString(4, venue);
            pstmt.setString(5, description);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event created successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void updateEvent(String id, String name, Date date, String time, String venue, String description) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE events SET name=?, date=?, time=?, venue=?, description=? WHERE id=?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setDate(2, new java.sql.Date(date.getTime()));
            pstmt.setString(3, time);
            pstmt.setString(4, venue);
            pstmt.setString(5, description);
            pstmt.setString(6, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event updated successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void deleteEvent(String id) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "DELETE FROM events WHERE id=?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event deleted successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void viewEvents() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM events";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            StringBuilder eventsList = new StringBuilder("Events:\n");
            while (rs.next()) {
                eventsList.append("ID: ").append(rs.getInt("id"))
                        .append(", Name: ").append(rs.getString("name"))
                        .append(", Date: ").append(rs.getDate("date"))
                        .append(", Time: ").append(rs.getString("time"))
                        .append(", Venue: ").append(rs.getString("venue"))
                        .append(", Description: ").append(rs.getString("description"))
                        .append("\n");
            }
            JOptionPane.showMessageDialog(null, eventsList.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new EventManagementSystem();
    }
}