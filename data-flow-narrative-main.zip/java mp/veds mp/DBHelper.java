import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBHelper {
    private static final String DB_URL = "jdbc:sqlite:paintapp.db";

    public DBHelper() {
        try {
            Class.forName("org.sqlite.JDBC");
            try (Connection conn = DriverManager.getConnection(DB_URL);
                 Statement stmt = conn.createStatement()) {
                String sql = "CREATE TABLE IF NOT EXISTS Paintings (id INTEGER PRIMARY KEY, image BLOB)";
                stmt.executeUpdate(sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            System.out.println("SQLite JDBC Driver not found!");
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection(DB_URL);
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite JDBC Driver Not Found!", e);
        }
    }

    public void saveImage(BufferedImage image) {
        String sql = "INSERT INTO Paintings (image) VALUES (?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBytes(1, ImageUtils.imageToBytes(image));
            pstmt.executeUpdate();
            System.out.println("Image Saved Successfully!");
        } catch (SQLException | IOException e) {
            System.err.println(" Error Saving Image: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<BufferedImage> loadImages() {
        List<BufferedImage> images = new ArrayList<>();
        String sql = "SELECT image FROM Paintings ORDER BY id ASC";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                byte[] imgBytes = rs.getBytes("image");
                if (imgBytes != null) {
                    images.add(ImageUtils.bytesToImage(imgBytes));
                }
            }
            System.out.println("Retrieved " + images.size() + " paintings from database!");

        } catch (SQLException | IOException e) {
            System.err.println(" Error Loading Paintings: " + e.getMessage());
            e.printStackTrace();
        }

        return images;
    }
}
