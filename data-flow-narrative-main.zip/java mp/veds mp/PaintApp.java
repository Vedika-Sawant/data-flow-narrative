import java.awt.*;
import java.io.IOException;
import java.sql.SQLException;
import javax.swing.*;

public class PaintApp extends JFrame {
    private PaintPanel paintPanel;

    public PaintApp() {
        setTitle("Virtual Painting App");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        paintPanel = new PaintPanel();
        add(paintPanel, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel();
        JButton clearButton = new JButton("Clear");
        JButton colorButton = new JButton("Color");
        JButton saveButton = new JButton("Save");
        JButton loadButton = new JButton("Load");

        String[] shapes = {"Freehand", "Line", "Rectangle", "Oval", "Circle", "Triangle", "Fill"};
        JComboBox<String> shapeBox = new JComboBox<>(shapes);
        JSlider brushSlider = new JSlider(1, 20, 5);

        clearButton.addActionListener(e -> paintPanel.clearCanvas());
        colorButton.addActionListener(e -> {
            Color newColor = JColorChooser.showDialog(null, "Choose a Color", Color.BLACK);
            if (newColor != null) paintPanel.setBrushColor(newColor);
        });
        shapeBox.addActionListener(e -> paintPanel.setDrawMode((String) shapeBox.getSelectedItem()));
        brushSlider.addChangeListener(e -> paintPanel.setBrushSize(brushSlider.getValue()));

        saveButton.addActionListener(e -> {
            try {
                paintPanel.saveToDatabase();
            } catch (SQLException | IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error saving to database!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        loadButton.addActionListener(e -> paintPanel.loadFromDatabase());

        controlPanel.add(colorButton);
        controlPanel.add(new JLabel("Brush Size"));
        controlPanel.add(brushSlider);
        controlPanel.add(shapeBox);
        controlPanel.add(clearButton);
        controlPanel.add(saveButton);
        controlPanel.add(loadButton);

        add(controlPanel, BorderLayout.SOUTH);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PaintApp().setVisible(true));
    }
}