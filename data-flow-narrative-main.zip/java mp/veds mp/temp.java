 
import java.util.*; 
class temp 
{ 
public static void main(String args[]) 
{ int a[]= {10,20,30,40,50}; 
int d; 
Scanner sc= new Scanner(System.in); 
System.out.println("Enter denominator:"); 
d=sc.nextInt(); 
try 
{ 
for(int i=0;i<=5;i++) { 
try 
{ 
int r= a[i]/d; 
System.out.println("Division = "+r); 
} 
catch(ArithmeticException e1) 
{ 
System.out.println("Divide by Zero is invalid"); 
break; 
} } 
} 
catch(ArrayIndexOutOfBoundsException e2) 
{ 
System.out.println("Array limit crossed..."); 
} 
} } 
