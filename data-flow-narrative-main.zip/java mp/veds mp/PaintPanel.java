import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Queue;
import javax.swing.*;

public class PaintPanel extends JPanel {
    private Color brushColor = Color.BLACK;
    private int brushSize = 5;
    private BufferedImage canvas;
    private Graphics2D g2d;
    private String drawMode = "Freehand";
    private int startX, startY, currX, currY;
    private boolean drawing = false;
    private DBHelper dbHelper = new DBHelper();

    public PaintPanel() {
        setPreferredSize(new Dimension(800, 500));
        canvas = new BufferedImage(800, 500, BufferedImage.TYPE_INT_ARGB);
        g2d = canvas.createGraphics();
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, 800, 500);
        g2d.setColor(brushColor);
        g2d.setStroke(new BasicStroke(brushSize));

        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                startX = e.getX();
                startY = e.getY();
                drawing = true;
                if (drawMode.equals("Fill")) {
                    fillArea(startX, startY, brushColor);
                }
            }
            public void mouseReleased(MouseEvent e) {
                if (!drawMode.equals("Freehand") && !drawMode.equals("Fill")) {
                    drawShape(g2d, startX, startY, e.getX(), e.getY());
                }
                drawing = false;
                repaint();
            }
        });

        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                currX = e.getX();
                currY = e.getY();
                if (drawMode.equals("Freehand")) {
                    g2d.setStroke(new BasicStroke(brushSize));
                    g2d.drawLine(startX, startY, currX, currY);
                    startX = currX;
                    startY = currY;
                }
                repaint();
            }
        });
    }

    private void drawShape(Graphics2D g, int x1, int y1, int x2, int y2) {
        int width = Math.abs(x2 - x1);
        int height = Math.abs(y2 - y1);
        int startX = Math.min(x1, x2);
        int startY = Math.min(y1, y2);
        g.setStroke(new BasicStroke(brushSize));

        switch (drawMode) {
            case "Line":
                g.drawLine(x1, y1, x2, y2);
                break;
            case "Rectangle":
                g.drawRect(startX, startY, width, height);
                break;
            case "Oval":
                g.drawOval(startX, startY, width, height);
                break;
            case "Circle":
                int diameter = Math.max(width, height);
                g.drawOval(startX, startY, diameter, diameter);
                break;
            case "Triangle":
                int[] xPoints = {x1, x2, (x1 + x2) / 2};
                int[] yPoints = {y1, y1, y2};
                g.drawPolygon(xPoints, yPoints, 3);
                break;
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(canvas, 0, 0, null);
        if (drawing && !drawMode.equals("Freehand") && !drawMode.equals("Fill")) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(brushSize));
            g2.setColor(brushColor);
            drawShape(g2, startX, startY, currX, currY);
        }
    }

    public void setBrushColor(Color color) {
        this.brushColor = color;
        g2d.setColor(color);
    }

    public void setBrushSize(int size) {
        this.brushSize = size;
    }

    public void setDrawMode(String mode) {
        this.drawMode = mode;
    }

    public void fillArea(int x, int y, Color newColor) {
        int targetColor = canvas.getRGB(x, y);
        int fillColor = newColor.getRGB();
        if (targetColor == fillColor) return;

        Queue<Point> queue = new ArrayDeque<>();
        queue.add(new Point(x, y));
        while (!queue.isEmpty()) {
            Point p = queue.poll();
            if (p.x < 0 || p.y < 0 || p.x >= canvas.getWidth() || p.y >= canvas.getHeight()) continue;
            if (canvas.getRGB(p.x, p.y) != targetColor) continue;
            canvas.setRGB(p.x, p.y, fillColor);
            queue.add(new Point(p.x + 1, p.y));
            queue.add(new Point(p.x - 1, p.y));
            queue.add(new Point(p.x, p.y + 1));
            queue.add(new Point(p.x, p.y - 1));
        }
        repaint();
    }

    public void clearCanvas() {
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        g2d.setColor(brushColor);
        repaint();
    }

    public void saveToDatabase() throws SQLException, IOException {
        dbHelper.saveImage(canvas);
    }

    public void loadFromDatabase() {
        List<BufferedImage> paintings = dbHelper.loadImages();
    
        if (paintings.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No paintings found in database.");
            return;
        }
    
        // Create a window to display all retrieved paintings
        JFrame galleryFrame = new JFrame("Gallery");
        galleryFrame.setSize(900, 600);
        galleryFrame.setLayout(new GridLayout(0, 3));
    
        for (BufferedImage image : paintings) {
            JLabel label = new JLabel(new ImageIcon(image));
            galleryFrame.add(label);
        }
    
        galleryFrame.setVisible(true);
        System.out.println(" Displayed " + paintings.size() + " paintings on the screen!");
    }
}